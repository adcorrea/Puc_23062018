package br.puc.se.designPatterns.creational.builder;

public class ResourceFileBuilder implements InputBuilder<String> {
	
	private String sPathFile;
	
	@Override
	public Input<String> build() {
		
		return new ResourceFileInput(sPathFile);
	}
	
	public ResourceFileBuilder fromResource(String sFile)
	{
		this.sPathFile = sFile;
		return this;
	}
	


}
