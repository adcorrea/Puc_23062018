package br.puc.se.designPatterns.creational.builder;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class HttpInputBuilder implements InputBuilder<HttpInputConnection> {
	
	private Properties connectionProperties;
	
	private String protocol;

	private String host;

	private String port;

	private String method;

	public HttpInputBuilder fromPropertyFile(String fileName) throws FileNotFoundException, IOException {
		this.connectionProperties = BuilderUtilities.readPropertiesFromResourceFile(fileName);
		return this;
	}

	@Override
	public Input<HttpInputConnection> build() {
		HttpInputConnection connection =  new HttpInputConnection();
		connection.setHost(this.host);
		connection.setPort(this.port);
		connection.setProtocol(this.protocol);
		connection.setMethod(this.method);
		return connection;
	}
	
	
	public HttpInputBuilder fromHost(String sHost)
	{
		this.host = sHost;
		return this;
	}
	
	public HttpInputBuilder usingProtocol(String sProtocol)
	{
		this.protocol = sProtocol;
		return this;
	}
	
	
	public HttpInputBuilder onPort(int iPort)
	{
		this.port = Integer.toString(iPort);
		return this;
	}
	
	public HttpInputBuilder usingMethod(String sMethod)
	{
		this.method = sMethod;
		return this;
	}

}
