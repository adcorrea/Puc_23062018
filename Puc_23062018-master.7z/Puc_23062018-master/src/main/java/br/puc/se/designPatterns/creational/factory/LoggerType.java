package br.puc.se.designPatterns.creational.factory;

public enum LoggerType {
	HTTP_POST, CONSOLE, FILE, JMS
}
